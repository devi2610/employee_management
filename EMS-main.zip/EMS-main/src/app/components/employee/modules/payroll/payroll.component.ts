import { Component } from '@angular/core';

@Component({
  selector: 'app-payroll',
  imports: [],
  templateUrl: './payroll.component.html',
  styleUrl: './payroll.component.css'
})
export class PayrollComponent {

}
