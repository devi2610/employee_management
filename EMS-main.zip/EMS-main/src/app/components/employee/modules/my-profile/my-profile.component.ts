import { Component } from '@angular/core';

@Component({
  selector: 'app-my-profile',
  standalone: true,
  template: `
    <div>
      <h2>My Profile</h2>
      <p>This is the employee's profile information.</p>
    </div>
  `,
})
export class MyProfileComponent {}
